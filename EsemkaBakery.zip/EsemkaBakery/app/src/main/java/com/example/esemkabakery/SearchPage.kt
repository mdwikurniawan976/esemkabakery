package com.example.esemkabakery

import android.content.ClipData.Item
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.esemkabakery.databinding.ActivitySearchPageBinding
import com.example.esemkabakery.databinding.ItemHomeBinding
import com.example.esemkabakery.databinding.ItemSearchBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

class SearchPage : AppCompatActivity() {
    lateinit var cari : String
    override fun onCreate(savedInstanceState: Bundle?) {
        class SearchA(val binding : ItemSearchBinding) : RecyclerView.ViewHolder(binding.root)
        class SearchView(val searh : JSONArray) : RecyclerView.Adapter<SearchA>(){
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchA {
             val inflate = ItemSearchBinding.inflate(LayoutInflater.from(parent.context),parent,false)
                return  SearchA(inflate)
            }

            override fun getItemCount(): Int {
              return  searh.length()
            }

            override fun onBindViewHolder(holder: SearchA, position: Int) {
             val item = searh.getJSONObject(position)
                holder.binding.nameCake.text = item.getString("name")
                GlobalScope.launch(Dispatchers.IO) {
                val bitmap =  BitmapFactory.decodeStream(URL(item.getString("imageURL")).openStream())
                runOnUiThread {
                    holder.binding.cakeImage.setImageBitmap(bitmap)
                }
                }


                holder.itemView.setOnClickListener {
                    val intent = Intent(this@SearchPage,DetailPage::class.java)
                    intent.putExtra("cakeID",item.getInt("cakeID"))
                    startActivity(intent)
                }
            }

        }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivitySearchPageBinding.inflate(layoutInflater)
        setContentView(binding.root)


        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("http://10.0.2.2:5000/api/Cake").openStream().bufferedReader().readText()
            val hasil = JSONArray(url)
            runOnUiThread {
                binding.rvSearch.adapter  = SearchView(hasil)
                binding.rvSearch.layoutManager =  GridLayoutManager(this@SearchPage,2)
            }
        }

        binding.btnSearch.setOnClickListener {
        val cari = binding.textSearch.text.toString()
            GlobalScope.launch(Dispatchers.IO) {
                val url = URL("http://10.0.2.2:5000/api/Cake?search=$cari").openStream().bufferedReader().readText()
                val result =  JSONArray(url)

                Log.d("search",result.toString())
                runOnUiThread {
                    binding.rvSearch.adapter =  SearchView(result)
                    binding.rvSearch.layoutManager =  GridLayoutManager(this@SearchPage,2)
                }
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}