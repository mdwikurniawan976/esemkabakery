package com.example.esemkabakery

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings.Global
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout.DispatchChangeEvent
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.esemkabakery.databinding.ActivityHomePageBinding
import com.example.esemkabakery.databinding.ItemHomeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

class HomePage : AppCompatActivity() {
    lateinit var  binding : ActivityHomePageBinding
    var id  = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
         binding = ActivityHomePageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.search.setOnClickListener {
            startActivity(Intent(this@HomePage,SearchPage::class.java))
        }
        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("http://10.0.2.2:5000/api/Cake").openStream().bufferedReader().readText()
            val result =  JSONArray(url)
            // buat mengambil detail
            val details = URL("http://10.0.2.2:5000/api/Cake/$id").openStream().bufferedReader().readText()
            val jsondetails=  JSONObject(details)

            GlobalScope.launch(Dispatchers.IO) {
                val bitmap =  BitmapFactory.decodeStream(URL(jsondetails.getString("imageURL")).openStream())
                runOnUiThread {
                    binding.imageHome.setImageBitmap(bitmap)
                }
            }

            val adapter =  object : RecyclerView.Adapter<CakeAdapter>(){
                override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CakeAdapter {
                    val inflate =  ItemHomeBinding.inflate(LayoutInflater.from(parent.context),parent,false)
                    return CakeAdapter(inflate)
                }

                override fun getItemCount(): Int {
                    return result.length()
                }

                override fun onBindViewHolder(holder: CakeAdapter, position: Int){
                    val item = result.getJSONObject(position)
                    holder.binding.nameCake.text =  item.getString("name")
                    GlobalScope.launch(Dispatchers.IO) {
                        val bitmap =  BitmapFactory.decodeStream(URL(item.getString("imageURL")).openStream())
                        GlobalScope.launch(Dispatchers.Main) {
                            holder.binding.cakeImage.setImageBitmap(bitmap)
                        }
                    }

                    holder.itemView.setOnClickListener {
                        //menampilkan detail dibawah ketika image atau name diatas di klik
                        binding.detailTampil.visibility  = View.VISIBLE
                        binding.price.text = "$" + item.getString("price")
                        binding.cakeName.text =  item.getString("name")

                        GlobalScope.launch(Dispatchers.IO) {
                            val url = URL("http://10.0.2.2:5000/api/Cake/${item.getInt("cakeID")}").openStream().bufferedReader().readText()
                            val hasil = JSONObject(url)
                            val image =  BitmapFactory.decodeStream(URL(hasil.getString("imageURL")).openStream())
                            runOnUiThread {
                            binding.cakeDeskripsi.text =  hasil.getString("description")
                                binding.imageHome.setImageBitmap(image)
                            }
                        }
                    }
                }
            }
            binding.order.setOnClickListener {
                startActivity(Intent(this@HomePage,OrderPage::class.java))
            }
            binding.rvHome.adapter = adapter
            binding.rvHome.layoutManager =  LinearLayoutManager(this@HomePage,LinearLayout.HORIZONTAL,false)
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    class CakeAdapter(val binding:ItemHomeBinding) : RecyclerView.ViewHolder(binding.root)
}