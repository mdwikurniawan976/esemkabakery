package com.example.esemkabakery

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.esemkabakery.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.email.setText("john_doe")
        binding.password.setText("password")
        binding.tvSignup.setOnClickListener {
            startActivity(Intent(this@MainActivity,RegisterPage::class.java))
            finish()
        }
        binding.btnSignin.setOnClickListener {
            if(binding.email.text.isEmpty() || binding.password.text.isEmpty()){
                Toast.makeText(this@MainActivity,"Field cannot be empty",Toast.LENGTH_LONG).show()
            }
            else{
                GlobalScope.launch(Dispatchers.IO) {
                    val url = URL("http://10.0.2.2:5000/api/Auth/Login").openConnection() as HttpURLConnection
                    url.requestMethod =  "POST"
                    url.setRequestProperty("Content-Type","application/json")


                    val json = JSONObject().apply {
                        put("usernameOrEmail",binding.email.text)
                        put("password",binding.password.text)
                    }
                    url.outputStream.write(json.toString().toByteArray())


                    if(url.responseCode in 200..299){
                        startActivity(Intent(this@MainActivity,HomePage::class.java))
                        finish()
                    }
                    else{
                        val error =  url.errorStream.bufferedReader().readText()
                        runOnUiThread {
                            Toast.makeText(this@MainActivity,"${JSONObject(error).getString("message")}",Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}