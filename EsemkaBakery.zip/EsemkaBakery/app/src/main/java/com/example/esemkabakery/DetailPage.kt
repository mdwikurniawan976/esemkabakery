package com.example.esemkabakery

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.esemkabakery.databinding.ActivityDetailPageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

class DetailPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivityDetailPageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val cakeId = intent.getIntExtra("cakeID",0)
        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("http://10.0.2.2:5000/api/Cake/$cakeId").openStream().bufferedReader().readText()
            val result = JSONObject(url)

            binding.detailName.text = result.getString("name")
            binding.detailDeskripsi.text = result.getString("description")
            binding.detailprice.text = "$"+ result.getString("price")
    //        GlobalScope.launch(Dispatchers.IO) {  }
            val image = BitmapFactory.decodeStream(URL(result.getString("imageURL")).openStream())
            runOnUiThread {
                binding.imageDetail.setImageBitmap(image)
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}