package com.example.esemkabakery

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.esemkabakery.databinding.ActivityOrderPageBinding
import com.example.esemkabakery.databinding.ItemOrderBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.net.URL

class OrderPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivityOrderPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("http://10.0.2.2:5000/api/Cake").openStream().bufferedReader().readText()
            val result = JSONArray(url)
            val adapter = object : RecyclerView.Adapter<OrderA>(){
                override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderA {
                    val inflate  = ItemOrderBinding.inflate(LayoutInflater.from(parent.context),parent,false)
                    return  OrderA(inflate)
                }

                override fun getItemCount(): Int {
                  return  result.length()
                }

                override fun onBindViewHolder(holder: OrderA, position: Int) {
                  val item = result.getJSONObject(position)
                    holder.binding.cakename.text = item.getString("name")
                    holder.binding.cakeprice.text = "$"+item.getString("price")
                    GlobalScope.launch(Dispatchers.IO) {
                        val bitmap =BitmapFactory.decodeStream(URL(item.getString("imageURL")).openStream())
                        runOnUiThread {
                            holder.binding.orderimage.setImageBitmap(bitmap)
                        }
                    }

                    holder.binding.plus.setOnClickListener {
                        var qty = holder.binding.qty.text.toString().toInt()
                        qty ++;
                        holder.binding.qty.text =  qty.toString()
                    }

                    holder.binding.minus.setOnClickListener {
                        var qty= holder.binding.qty.text.toString().toInt()
                        if(qty >= 2){
                            qty --;
                            holder.binding.qty.text = qty.toString()
                        }
                    }
                }
            }
            binding.rvOrder.adapter =  adapter
            binding.rvOrder.layoutManager = LinearLayoutManager(this@OrderPage)
        }


        binding.btnCheckout.setOnClickListener {
            startActivity(Intent(this@OrderPage,CheckoutPage::class.java))
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    class OrderA(val binding: ItemOrderBinding) : RecyclerView.ViewHolder(binding.root)
}