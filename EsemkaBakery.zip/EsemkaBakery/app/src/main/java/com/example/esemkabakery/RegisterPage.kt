package com.example.esemkabakery

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.esemkabakery.databinding.ActivityRegisterPageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class RegisterPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val binding = ActivityRegisterPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSingup.setOnClickListener {
            if(binding.emails.text.isEmpty() || binding.firstname.text.isEmpty() || binding.lastname.text.isEmpty() || binding.username.text.isEmpty() || binding.password.text.isEmpty() || binding.confirmpassword.text.isEmpty()){
                Toast.makeText(this@RegisterPage,"Fields cannot be empty",Toast.LENGTH_LONG).show()
            }
            else if(binding.password.text.toString() != binding.confirmpassword.text.toString()){
                Toast.makeText(this@RegisterPage,"Password and confirm not same",Toast.LENGTH_LONG).show()
            }
            else{
                GlobalScope.launch(Dispatchers.IO) {
                    val url = URL("http://10.0.2.2:5000/api/Auth/Register").openConnection() as HttpURLConnection
                    url.requestMethod = "POST"
                    url.setRequestProperty("Content-Type","application/json")

                    val json =  JSONObject().apply {
                        put("username",binding.username.text)
                        put("password",binding.password.text)
                        put("lastName",binding.lastname.text)
                        put("firstName",binding.firstname.text)
                        put("email",binding.emails.text)
                        put("passwordConfirmation",binding.confirmpassword.text)
                    }

                    url.outputStream.write(json.toString().toByteArray())

                    if(url.responseCode in 200..299){
                        startActivity(Intent(this@RegisterPage,HomePage::class.java))
                        finish()
                    }
                    else{
                        val error =  url.errorStream.bufferedReader().readText()
                        runOnUiThread {
                            Toast.makeText(this@RegisterPage,"${JSONObject(error).getString("message")}",Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        binding.tvSignin.setOnClickListener {
            startActivity(Intent(this@RegisterPage,MainActivity::class.java))
            finish()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}